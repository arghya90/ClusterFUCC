#!/usr/bin/env python

from setuptools import setup
from setuptools import find_packages

with open("README.md", "r") as freadme:
	long_description = freadme.read()

setup(
	## METADATA ##
	name = 'ClusterFUCC', 
	author = 'Arghya \"Argo\" Chakravorty', 
	version="1.0.1",
	author_email = 'arghyac@umich.edu',
	description = 'A python package of tools of clustering conformations by fraction of common contacts.',
	long_description = long_description,
	
	## OPTIONS ##
	packages = find_packages('src'),
	package_dir = {'' : 'src'},

	# can be run as a zip
	zip_safe = False,
)
