# ClusterFUCC

ClusterFUCC is a python package whose core purpose is the 
implementation of the Fraction of Common Contacts clustering method 
as mentioned in a Proteins 2012 paper of Bonvin et. al. 
DOI: 10.1002/prot.24078


