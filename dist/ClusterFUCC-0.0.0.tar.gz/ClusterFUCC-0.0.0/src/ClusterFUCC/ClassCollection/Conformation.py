import os, sys
from collections import Set

class Conformation(object):
    """A class that represents the conformation of a system by the number of heavy atom contacts in it."""
    
    def __init__(self):
        self.time = None
        self.ncontacts = 0
        self.contacts = set()
        self.neighbors = set()
        self.clustered = False
        self.clusterId = -1
        
    def update_neighbors(self):
        newList = set()
        for nn in self.neighbors:
            if not nn.clustered:
                newList.add(nn)
                
        self.neighbors = newList
        return
    
    def get_timeStamp(self):
        return str(self.time)
    
    def __eq__(self, other):
        return self.time == other.time
    
    def __gt__(self, other):
        return self.time > other.time
    
    def __lt__(self, other):
        return self.time < other.time
    
    def __hash__(self):
        return hash(self.time)
    
    #END