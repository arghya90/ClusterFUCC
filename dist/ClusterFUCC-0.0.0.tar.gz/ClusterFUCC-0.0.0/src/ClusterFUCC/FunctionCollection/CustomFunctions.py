import numpy as nmp
from collections import Set
from ClusterFUCC.ClassCollection import Conformation, Cluster

def get_FCC(arg_conf1, arg_conf2):
    """
    Return the percent similarity of the contacts in two objects of Class Conformation.
    """
    cc12 = arg_conf1.contacts.intersection(arg_conf2.contacts)
    fcc12 = 100 * len(cc12)/arg_conf1.ncontacts
    
    return fcc12
#END

def fetch_max_cluster(arg_maxIdx, arg_cluster, arg_timeStamps, arg_confDict, arg_deque):
    maxTimeStamp = arg_timeStamps[arg_maxIdx]
    print('Trying to make a cluster around conf at {}'.format(maxTimeStamp))
    
    if not arg_confDict[maxTimeStamp].clustered:
        arg_cluster.centroid = arg_confDict[maxTimeStamp]
        print('Conf at {} is chosen as centroid'.format(maxTimeStamp))
        
        arg_cluster.members.add(arg_cluster.centroid) # add the centroid as a member of the cluster
        
        for nn in arg_confDict[maxTimeStamp].neighbors:
            if not nn.clustered:
                arg_cluster.members.add(nn)
        
        print('... of a cluster of size {} '.format(len(arg_cluster.members)))
        
        # flag all the members of this cluster
        for iMemb in arg_cluster.members:
            iMemb.clustered = True
            iMemb.clusterId = arg_cluster.clusterID
            # print(iMemb.time)
        
    else:
        print('...Failed.')
        if len(arg_deque) == 0:
            print('No more conformations left to examine.')
            return None
        
        else:
            print('Looking for the conformation next in the sequence in deque...')        
            maxIdx = arg_deque.popleft()
            fetch_max_cluster(maxIdx, arg_cluster, arg_timeStamps, arg_confDict, arg_deque)
            
    return 
#END

def rejig_members_in_cluster(arg_cid, arg_clusterList):
    """
    Checks if a member of the input cluster should belong to any other cluster
    which is possible if it is closer to that centroid than the current one.
    """
    # current Cluster
    try:
        currCluster = list(filter(lambda CL: CL.clusterID == arg_cid, arg_clusterList))[0]
    except:
        raise IndexError("No cluster with cluster ID {} found.".format(arg_cid))

    # exclusion list for current cluster 
    otherClusters =filter(lambda CL: CL.clusterID != arg_cid, arg_clusterList)

    # see if members of current cluster can be sent to a different cluster
    # by measuring the FCC with their centroid
    for imem in currCluster.members:

        # measure its FCC with current centroid
        currFCC = get_FCC(imem, currCluster.centroid)

        for oCL in otherClusters:
            otherFCC = get_FCC(imem, oCL.centroid)

            if otherFCC > currFCC:
                oCL.members.add(imem)
                imem.clusterId = oCL.clusterID

                currCluster.members.remove(imem)
                print("Conf with timestamp {} moved from cluster {} to cluster {}".\
                      format(imem.get_timeStamp(), currCluster.clusterID, oCL.clusterID))
                
    return
#END

def fetch_cluster_common_contacts(arg_cid, arg_clusterList):
    """
    Identifies contacts that are common across all the members of the 
    cluster with input cluster ID and returns the set of common contacts.
    """
    commonContacts = None

    # current Cluster
    try:
        currCluster = list(filter(lambda CL: CL.clusterID == arg_cid, arg_clusterList))[0]
    except:
        raise IndexError("No cluster with cluster ID {} found.".format(arg_cid))

    # spot the centroid
    centroid = currCluster.centroid

    # initialize a set of common contacts
    commonContacts = centroid.contacts

    # update the set of common contacts after examining each pair
    for imem in currCluster.members:
        commonContacts = commonContacts.intersection(imem.contacts)

    # what percent of centroid contacts is common throughout the cluster
    percCommon = 100 * len(commonContacts)/len(centroid.contacts)
    # print("{:.1f}% contacts are common across cluster {} ".format(percCommon, arg_cid))

    return (percCommon, commonContacts)
#END
