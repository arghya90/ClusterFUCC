import os, sys
from collections import Set

class Cluster(object):
    """
    A class that represents a cluster of conformations put 
    together because they are close to each other by some metric.
    """
    
    def __init__(self, arg_idx):
        self.clusterID = arg_idx
        self.members = set()
        self.centroid = None
        
    def __eq__(self, otherCluster):
        return self.clusterID == otherCluster.clusterID
    
    def __lt__(self, otherCluster):
        return self.clusterID  < otherCluster.clusterID
    
    def __gt__(self, otherCluster):
        return self.clusterID  > otherCluster.clusterID
    
    def get_size(self):
        return len(self.members)

    def get_common_contacts(self):
        """
        Identifies contacts that are common across all the members of this 
        cluster returns that set.
        """
        commonContacts = None

        # initialize a set of common contacts
        commonContacts = self.centroid.contacts

        # update the set of common contacts after examining each pair
        for imem in self.members:
            commonContacts = commonContacts.intersection(imem.contacts)

        # what percent of centroid contacts is common throughout the cluster
        percCommon = 100 * len(commonContacts)/len(self.centroid.contacts)

        return (percCommon, commonContacts)
    #END

    def get_contact_weights(self):
        """
        Survey all the contacts across all the members in this cluster 
        and return a list of 2-tuples (contactID, contactWeight) where
        contactWeight is the percentage of members it is present in.
        """

        contWeights = dict()
        for imem in self.members:
            for contID in imem.contacts:
                try:
                    contWeights[contID] += 1
                except KeyError:
                    contWeights[contID] = 1

        print('A total of {} unique contacts are present in the members of cluster {}'.format(len(contWeights), self.clusterID), flush = True)

        for ckey in contWeights.keys():
            contWeights[ckey] = 100.0 * contWeights[ckey]/self.get_size()
            
        return contWeights
    #END
