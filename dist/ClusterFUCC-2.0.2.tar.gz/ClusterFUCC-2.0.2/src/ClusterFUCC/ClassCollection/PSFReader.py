""" This is a X-PLOR format PSF file reader """
__author__ = "Arghya Chakravorty"

import sys, os, re
import numpy as nmp

from ClusterFUCC.ClassCollection import BaseMolecule

VECTORDIM = 3

class PsfAtomType(object):
    """ A class that stores the information about certain physical properties of a type of atom. the structure is designed to suit the information
    stored in a PSF file."""
    def __init__(self, arg_atomType, **kwargs):
        self.atomType = arg_atomType
        
        for prop, val in kwargs.items():
            setattr(self, prop, val)
#END

class PsfTopology(object):
    """ A class that reads X-PLOR or CHARMM format PSF file """

    def __init__(self, arg_fileName):
        self.psfFile = arg_fileName

        # dictionary mapping residue indices with residue name
        # designed in order to appropriately populate residue based information (linked list format)
        # in the BaseMolecule instance
        self.residueDict= dict()

        # dictionary <int : PsfAtomType> of gromacs atomtypes
        self.psfAtomTypeDict = dict()

       
    def read_psfFile(self):
        """ Reads the input PSF file and returns an instance of BaseMolecule if successfully read"""

        # local variables
        isValidPSF = False
        isFormatSTD = False
        isFormatEXT = False
        isFormatCMAP = False
        isFormatCHEQ = False
        isFormatDRUDE = False
        isFormatXPLOR = False
        isFormatNAMD = False

        canReadAtom = False
        canReadBond = False
        canReadAngle = False
        canReadDihed = False

        # create an instance of BaseMolecule
        newMolecule = BaseMolecule.BaseMolecule(arg_name = '')

        # for the sake of compatibility with information in gromacs's TPR file, add these information in 'newMolecule'
        # which are essentially dummies
        newMolecule.numCopies = 1


        # open file handler and read all the contents into a buffer
        with open(self.psfFile, 'r') as psfFileHandler:
            psfBuffer = psfFileHandler.readlines()

        i = 0
        atIdx = 0
        lastResidueIdx = -1
        lastResid = -1

        while ( i <= len(psfBuffer)):

            # read the i-th line
            line = psfBuffer[i]

            # skip blank lines
            if len(line.strip()) == 0:
                i += 1
                continue
                
            # look for "PSF" in the very first line
            if line[0:3] == "PSF" and not isValidPSF:
                isValidPSF = True
                psfFormat = " "
                print("Valid PSF found.")

                # learn the format
                if "EXT" in line.strip():
                    # Extended format PSF  (CHARMM)
                    isFormatEXT = True
                    psfFormat = "{} EXT".format(psfFormat)
                    print(psfFormat)

                if "CHEQ" in line.strip():
                    # Extended format PSF and CHEQ
                    isFormatCHEQ = True
                    psfFormat = "{} CHEQ".format(psfFormat)
                    print(psfFormat)

                if "CMAP" in line.strip():
                    # Extended format PSF and CMAP
                    isFormatCMAP = True
                    psfFormat = "{} CMAP".format(psfFormat)
                    print(psfFormat)

                if "DRUDE" in line.strip():
                    # Extended format PSF and DRUDE
                    isFormatDRUDE = True
                    psfFormat = "{} DRUDE".format(psfFormat)
                    print(psfFormat)

                if "XPLOR" in line.strip():
                    # Extended format PSF and XPLOR
                    isFormatXPLOR = True
                    psfFormat = "{} XPLOR".format(psfFormat)
                    print(psfFormat)

                if "NAMD" in line.strip():
                    # NAMD/VMD format PSF
                    isFormatNAMD = True
                    psfFormat = "{} NAMD".format(psfFormat)
                    print(psfFormat)

                # if none of the above then it is standard format
                if ( (not isFormatEXT) and (not isFormatNAMD)):
                    # std format
                    isFormatSTD = True
                    psfFormat = "{} STD".format(psfFormat)
                    print(psfFormat)

                i += 1
                continue

                    
            ######### REMARKS #########
            if re.match("^[0-9]+ !NTITLE$", line.strip()) and isValidPSF:
                searchRes = re.search("^([0-9]+) !NTITLE$", line.strip())
                nTitles = int(searchRes.group(1))
                print('Found {} remark lines. They will be skipped.'.format(nTitles))
                i += (1 + nTitles)   # skip these many lines
                continue
            
            
            if re.match("^[0-9]+ !NATOM$", line.strip()) and isValidPSF and not canReadAtom:
                canReadAtom = True
                searchRes = re.search("^([0-9]+) !NATOM$", line.strip())
                nAtoms = int(searchRes.group(1))
                print('Read {} atoms in the system'.format(nAtoms))

                i += 1  
                continue
             
            ######### ATOMS #########   
            if canReadAtom:

                # time to change flags to enable reading Bond information if NBOND is encountered
                if re.match("^[0-9]+ !NBOND", line.strip()):
                    canReadAtom = False
                    canReadBond = True
                    
                    # Before proceeding 
                    # 1. fill residue index and name information
                    newMolecule.numAtoms = nAtoms
                    newMolecule.numAtomsPerCopy = newMolecule.numAtoms
                    newMolecule.numResidues = len(newMolecule.resnameArray)

                    # 2. correctly fill the cell-linked-list formatted residue information 
                    newMolecule.atomArray = nmp.zeros(newMolecule.numAtoms)
                    newMolecule.residueHead = -1 * nmp.ones(newMolecule.numResidues)

                    for aid, rid in enumerate(newMolecule.atomResidueIdxArray):
                        newMolecule.atomArray[aid] = newMolecule.residueHead[rid]
                        newMolecule.residueHead[rid] = aid


                    # 3. Also before fetching information about bonds, it needs to know 
                    #    the nature of the atoms involved in the bond.
                    #    i.e. is it C, Ca, N, BB, H, etc.
                    # So now that all the atom inforamtion is supposed to have been read, 
                    # use it to prepare these arrays in the 
                    # instance of BaseMolecule

                    # initialize
                    newMolecule.initialize_element_info_arrays()

                    # assign element types and priorities
                    newMolecule.populate_element_info_arrays()


                    # make a final check on the above assignments to the BaseMolecule instance
                    newMolecule.validate_assignments()

                    searchRes = re.search("^([0-9]+) !NBOND", line.strip())
                    nBonds = int(searchRes.group(1))
                    print('Read {} bonds in the structure'.format(nBonds))


                else:
                    # print(line)
                    # STD format
                    if isFormatSTD:
                        # // (I8,1X,A4,1X,A4,1X,A4,1X,A4,1X,I4,1X,2G14.6,I8)
                        # //  II,LSEGID,LRESID,LRES,TYPE(I),IAC(I),CG(I),AMASS(I),IMOVE(I)
                        atomSegname = line[9:13].strip()
                        atomResid = int(line[14:18])
                        atomResname = line[19:23].strip()
                        atomName = line[24:28].strip()
                        atomMass = float(line[48:64])

                    elif isFormatEXT and isFormatCHEQ:
                        # In charmm's src code, the detailed information of the
                        #  correct string format of PSF based on PSF tags can be found.
                        # This formatting here is based on that.
                        # Obviosuly the control flow and the condition blocks are
                        # not placed like it is the CHARMM code.

                        if isFormatXPLOR:
                            # (I10,1X,A8,1X,A8,1X,A8,1X,A8,1X,A6,1X,2G14.6,I8,2G14.6)
                            # II,LSEGID,LRESID,LRES,TYPE(I),IAC(I),CG(I),AMASS(I),IMOVE(I)
                            atomSegname = line[11:19].strip()
                            atomResid = int(line[20:28])
                            atomResname = line[29:37].strip()
                            atomName = line[38:46].strip()
                            atomMass = float(line[68:82])

                        elif not isFormatXPLOR:
                            # (I10,1X,A8,1X,A8,1X,A8,1X,A8,1X,I4,1X,2G14.6,I8,2G14.6)
                            # II,LSEGID,LRESID,LRES,TYPE(I),IAC(I),CG(I),AMASS(I),IMOVE(I)
                            # SECRET: the region that is diff (A6 vs I4) is of no use here. 
                            # but still, just to be clear!
                            atomSegname = line[11:19].strip()
                            atomResid = int(line[20:28])
                            atomResname = line[29:37].strip()
                            atomName = line[38:46].strip()
                            atomMass = float(line[68:82])

                    # update current residue
                    if lastResid != atomResid:
                        newMolecule.residArray.append(atomResid)
                        newMolecule.resnameArray.append(atomResname)
                        lastResid = atomResid
                        lastResidueIdx += 1


                    # populate atom-based indices of BaseMolecule instance
                    # print('Adding entry: ATOM {} {} {} {}'.format(atomIdx, atomName, atomResname, lastResid))
                    newMolecule.atomIndexArray.append(atIdx)
                    newMolecule.atomResidueIdxArray.append(lastResidueIdx)
                    newMolecule.atomNameArray.append(atomName)
                    newMolecule.atomMassArray.append(atomMass)
                    newMolecule.atomSegnameArray.append(atomSegname)

                    atIdx += 1

                i += 1
                continue
                
            ######### BONDS #########
            if canReadBond:
                # read bond information
                if re.match("^[0-9]+\s+[0-9]+", line.strip()):
                    # each line has at most 4 bond pairs
                    # print('Reading bond', line)
                    atomsInLine = line.strip().split()
                    assert(len(atomsInLine) % 2 == 0 and 2 <= len(atomsInLine) <= 8)  # should have 2K (k=1, 2, 3 or 4) indices
                    jdx = 0
                    while jdx < len(atomsInLine):
                        aidI, aidJ = nmp.sort([ (int(atomsInLine[jdx + i]) - 1) for i in range(2) ])
                        newMolecule.add_bond_tree(arg_aidI=aidI, arg_aidJ=aidJ)
                        jdx += 2
                    
            
                # time to change flags   
                elif re.match("^[0-9]+ !NTHETA", line.strip()):
                    canReadBond = False
                    canReadAngle = True
                    searchRes = re.search("^([0-9]+) !NTHETA", line.strip())
                    nAngles = int(searchRes.group(1))
                    print('Read {} angles in the structure'.format(nAngles))
                    
                i += 1
                continue
        
            ######### ANGLES #########
            if canReadAngle:
                # read angle information
                if re.match("^[0-9]+\s+[0-9]+\s+[0-9]+", line.strip()):
                    # each line has at most 3 angle triplets
                    # print('Reading angle', line)
                    atomsInLine = line.split()
                    assert(len(atomsInLine) % 3 == 0 and 3 <= len(atomsInLine) <= 9)  # should have 3K (k=1,2 or 3) indices
                    
                    # do nothing because angle information is not used anywhere throughout
                    pass                   
             
                elif re.match("^[0-9]+ !NPHI", line.strip()):
                    canReadAngle = False
                    canReadDihed = True
                    searchRes = re.search("^([0-9]+) !NPHI", line.strip())
                    nDiheds = int(searchRes.group(1))
                    print('Read {} dihedrals in the structure'.format(nDiheds))
                    
                i += 1
                continue
             
            ######### DIHEDRALS #########   
            if canReadDihed:
                # read dihedral information
                if re.match("^[0-9]+\s+[0-9]+\s+[0-9]+\s+[0-9]+", line.strip()):
                   
                    # each line has at most 2 dihedral quadruples
                    # print('Reading dihedral', line)
                    atomsInLine = line.strip().split()
                    assert(len(atomsInLine) % 4 == 0 and 4 <= len(atomsInLine) <= 8)  # should have 4K (k=1 or 2) indices
                    
                    # do nothing because angle information is not used anywhere throughout
                    pass
                
                elif re.match("^[0-9]+ !N", line.strip()):
                    canReadDihed = False

                i += 1
                continue

  
            ######### IGNORE EVERYTHING ELSE #########
            else:
                # if anything else shows up (like Improper, Cross-term, non-bonded params, etc. )
                # ignore them till the end of the PSF file
                #
                # Hopefully everything that is needed has been read in already!
                #
                break
        

        if (isValidPSF and nAtoms > 0 and nBonds > 0 and nAngles > 0 and nDiheds > 0):
            return newMolecule
        else:
            return None
#END

    
