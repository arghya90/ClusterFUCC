import os, sys
from collections import Set

class Cluster(object):
    """
    A class that represents a cluster of conformations put 
    together because they are close to each other by some metric.
    """
    
    def __init__(self, arg_idx):
        self.clusterID = arg_idx
        self.members = set()
        self.centroid = None
        
    def __eq__(self, otherCluster):
        return self.clusterID == otherCluster.clusterID
    
    def __lt__(self, otherCluster):
        return self.clusterID  < otherCluster.clusterID
    
    def __gt__(self, otherCluster):
        return self.clusterID  > otherCluster.clusterID
    
    def get_size(self):
        return len(self.members)
