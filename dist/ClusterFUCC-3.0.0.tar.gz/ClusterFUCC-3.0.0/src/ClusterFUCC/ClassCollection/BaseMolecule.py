import numpy as nmp
import re
import sys
from collections import Set

from ClusterFUCC.ClassCollection import Tree


class BaseMolecule(object):
    """ A class that contains topographical and composition information of a molecule"""

    def __init__(self, arg_name):
        self.name = arg_name
        self.numAtoms = 0
        self.numResidues = 0
        self.numCopies = 0
        self.numAtomsPerCopy = 0

        self.residArray = []  #an array of residue indices as they appear in the input file 
        self.resnameArray = [] #an array of resnames "???" in the order of their resids as they appear in the input file

        self.atomResidueIdxArray =  [] # an array of residue indices in which they are read (0-indexed) of the length of the number of atoms
        self.atomNameArray = [] # an array of the name of atoms as they appear in the input file
        self.atomIndexArray = [] # an array of atom IDs as they appear in the input file
        self.atomMassArray = [] # an array of atom masses as they appear in the input 
        self.atomChargeArray = [] # an array of atom charges as they appear in the input
        self.atomSegnameArray = [] # an array of segnames associated with each atom
        
       

        # this is to help with the obtaining bonding information
        # the heads of a cell-linked-list structure
        # each entry is the last atom index as read from the input file that belongs to the residue on that index
        self.residueHead = None

        # the atoms array contains information about which residue the atoms belong to.
        # the idea is the same as cell-linked list
        self.atomArray = None

        # arrays storing element type information for atoms for easier access during runtime
        # length = totalNumAtom = numCopies * numAtomsPerCopy
        self.isCAtomArray = []
        self.isOAtomArray = []
        self.isNAtomArray = []
        self.isCaAtomArray = []
        self.isBBAtomArray = []
        self.isHydrogenArray = []

        # this is especially for united atom (UA) level of hierarchy
        # each atom is either a heavy atom or an atom bonded to a heavy atom
        # so each atom has an index associated with it which is the index
        # of the heavy atom it is bonded to (including itself)
        
        # this is an array that containes the information about 
        # which heavy atoms this certain atom is bonded to. (including itself if it is a heavy atom)
        self.hostHeavyAtomArray = []

        # this is a dictionary  <atom id : binary tree> that containes the information about 
        # which hydrogens atoms this certain atom is bonded to.
        # Each node contains a value which is a 2-tuple of the form (priority, atom_index)
        # The design of the tree is sorted by priority levels
        self.bondedHydrogenTable = dict()


        # this is a dictionary  <atom id : binary tree> that containes the information about 
        # which heavy atoms this certain atom is bonded to.
        # Each node contains a value which is a 2-tuple of the form (priority, atom_index)
        # The design of the tree is sorted by priority levels
        self.bondedHeavyAtomTable = dict()

        # bondArray
        # bonds (covalent) in the structure
        # array of instances of class `Bond`
        self.bondArray = []


        # angleArray
        # angles in the structure
        # arrat of instances of class `Angle`
        self.angleArray = []

        # angle table
        self.angleTable = dict()

        # dihedralArray
        # set of objects of Class `Dihedral`
		# this is to avoid storing dihedral information redundantly. Packages like gromacs have a single dihedral 
		# treated with more than one function and so the way we are reading the topology, we might overcount dihedrals.
        self.dihedralArray = []

        # this is a dictionary  <atom id : binary tree> that containes the information about 
        # which  dihedral bonds an atom is associated with.
        # The key is atom index and its value is a binary tree where
        # each node is an instance of Class Dihedral.
        # It could very well have been a list of 'Dihedrals' but the idea was to introduce 
        # the use of 'Disjoint sets' to be able to find common dihedrals.
        # hopefully this will be time-effcient and importantnyl, elegent
        self.dihedralTable = dict()

        # connectivity matrix
        # a matrix with values 2 3 and 4 to indicate connectivity 
        # between pairs of atoms by bond (2), angle (3) or dihedral (4)
        self.connectivity = None

        
        # residueDict
        # it is a compound dictionary
        # Keys of the main dictionary are interger (0-numResidues)
        # Key, value pair of the secondary dictionary are 
        #   Residue name : resid
        #   atom id      : atom name (notice the order is reversed now)
        self.residueDict = dict()

        # # atomOfResidueDict:
        # # it is a compound dictionary
        # # A dict <int (0-numResidues) :  dict(<str (atomname) : int (atom-index)>) >
        # self.atomsOfResidueDict = dict()

        # a dictionary of < int (0-numAtoms): Atom> format
        self.atomsDict = dict()
       

# END    
        
    def validate_initialization(self):
        """ Validate the entries by checking the identity of the lengths of the different arrays"""
        assert(len(self.residueIndexArray) == len(self.residArray))
        assert(len(self.residArray)        == len(self.resnameArray))

        assert(len(self.atomNameArray)     == len(self.atomIndexArray))
        assert(len(self.atomsDict)         == len(self.atomIndexArray))

        assert(len(self.bondedHydrogenTable) == len(self.atomIndexArray))
        assert(len(self.bondedHeavyAtomTable) == len(self.atomIndexArray))

        for iAtom in self.atomIndexArray:
            # that trees have no values
            assert(len(self.bondedHeavyAtomTable[iAtom]) == 0)
            assert(len(self.bondedHydrogenTable[iAtom]) == 0)

        return
# END
        
    def validate_assignments(self):
        assert(self.numResidues == len(self.residueHead))
        assert(self.numResidues == len(self.residArray))
        assert(self.numResidues == len(self.resnameArray))

        assert(self.numAtoms == len(self.atomResidueIdxArray))
        assert(self.numAtoms == len(self.atomArray))
        assert(self.numAtoms == len(self.atomNameArray))
        assert(self.numAtoms == len(self.atomIndexArray))
        assert(self.numAtoms == len(self.atomMassArray))
        
        return
# END

    def initialize_element_info_arrays(self):
        """ initialize arrays storing information about atom types and priority levels"""
        try:
            assert(self.numCopies * self.numAtomsPerCopy != 0)
        except:
            print('Arrays cannot be initialized if the molecule does not have any atom')
            return

        self.isCAtomArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)
        self.isOAtomArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)
        self.isNAtomArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)
        self.isCaAtomArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)
        self.isBBAtomArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)
        self.isHydrogenArray = nmp.zeros(self.numCopies * self.numAtomsPerCopy)

        self.connectivity = nmp.eye(self.numCopies * self.numAtomsPerCopy)

        return
#END

    def populate_element_info_arrays(self):
        """ After initialization, element info arrays are filled with appropriate values """
        # assign element types and priorities                                

        for atIdx in range(self.numCopies * self.numAtomsPerCopy):
            

            # initialize bond list for each atom
            self.bondedHydrogenTable[atIdx] = set()
            self.bondedHeavyAtomTable[atIdx] = set()

            # initialize angle list for each atom
            self.angleTable[atIdx] = set()
                
            # initialize dihedral list for each atom
            self.dihedralTable[atIdx] = set()

            # assign atomtype using atomname
            atName = self.atomNameArray[atIdx % (self.numAtoms) ]
            
            if re.match("^C$",atName):
                self.isCAtomArray[atIdx] = 1
                self.isBBAtomArray[atIdx] = 1
                
            elif re.match("^N$",atName):
                self.isNAtomArray[atIdx] = 1
                self.isBBAtomArray[atIdx] = 1
                
            elif re.match("^CA$",atName):
                self.isCaAtomArray[atIdx] = 1
                self.isBBAtomArray[atIdx] = 1
                
            elif re.match("^O$",atName):
                self.isOAtomArray[atIdx] = 1
                self.isBBAtomArray[atIdx] = 1

            elif re.match("H[A-Z]{0,}[0-9]{0,}",atName):
                self.isHydrogenArray[atIdx] = 1

        # cast into integers
        self.atomArray = self.atomArray.astype(int)
        self.isCAtomArray = self.isCAtomArray.astype(int)
        self.isNAtomArray = self.isNAtomArray.astype(int)
        self.isCaAtomArray = self.isCaAtomArray.astype(int)
        self.isBBAtomArray = self.isBBAtomArray.astype(int)
        self.isHydrogenArray = self.isHydrogenArray.astype(int)

        return
    #END

    def add_bond(self, arg_bond):

        # add the input atoms to each others' list
        idx1, idx2 = arg_bond.atomList

        # print("Adding {} and {}".format(arg_aidI, arg_aidJ))


        # make sure both atoms are not hydrogen atoms
        try:
            assert(not (self.isHydrogenArray[idx1] and self.isHydrogenArray[idx2]))
        except:
            print('!!! WARNING : Requesting bond between two hydrogen atoms : ({:>3d}) and ({:>3d}) !!!'.format(idx1, idx2), flush = True)
            return
        
        # expect a pair to be noH-H or noH-noH 
        iH = -1
        iNonH1 = -1
        iNonH2 = -1


        if self.isHydrogenArray[idx1]:
            iH = idx1
            iNonH1 = idx2

        elif self.isHydrogenArray[idx2]:
            iH = idx2
            iNonH1 = idx1
        else:
            iNonH1 = idx1
            iNonH2 = idx2

        if iNonH1 != -1 and iNonH2 != -1:
        	self.bondedHeavyAtomTable[iNonH1].add(iNonH2)
        	self.bondedHeavyAtomTable[iNonH2].add(iNonH1)

        else:
        	self.bondedHydrogenTable[iNonH1].add(iH)
        	self.bondedHeavyAtomTable[iH].add(iNonH1)

        # add bond to the bond array
        self.bondArray.append(arg_bond)

        # update the connectivity matrix
        self.connectivity[idx1, idx2] = 2
        self.connectivity[idx2, idx1] = 2

        return
    # END

    def add_angle(self, arg_angle):
        """ Add the angle to the array of angles and for 
        each of its atoms, add an entry to their angle table."""
        
        for atIdx in arg_angle.atomList:
            self.angleTable[atIdx].add(arg_angle)
        
        # add angle to the angle array
        self.angleArray.append(arg_angle)

        # update the connectivity matrix
        idx1 = arg_angle.atom1
        idx3 = arg_angle.atom3
        self.connectivity[idx1, idx3] = 3
        self.connectivity[idx3, idx1] = 3

        return
    #END

    def add_dihedral(self, arg_dihedral):
        """ Add the dihedral to the array of dihedrals and for 
        each of its atoms, add an entry to their dihedral table."""

        for atIdx in arg_dihedral.atomList:
            # print('Adding dihedral {} to the list for atom {}'.format(arg_dihedral, atIdx))
            self.dihedralTable[atIdx].add(arg_dihedral)
        
        # add dihedral to the dihedral array
        self.dihedralArray.append(arg_dihedral)

        # update the connectivity matrix
        idx1 = arg_dihedral.atom1
        idx4 = arg_dihedral.atom4
        self.connectivity[idx1, idx4] = 4
        self.connectivity[idx4, idx1] = 4
        return
    #END


    def print_residue_info(self, arg_resindex):
        """ print residue information in the prescribed format"""
        
        print("{:>6s}{:>8s}{:>4s}{:>4s}{:>4s}{:>4s}{:>4s}{:>10s}".format("Idx","Name","isC", "isN", "isCa","isBB","isH", "bondedTo"), flush = True)
        print('-'*50, flush = True)
        iAtom = int(self.residueHead[arg_resindex])
        while iAtom != -1:
            print("{:>6}{:>8}{:>4}{:>4}{:>4}{:>4}{:>4}{:>10}".\
            	format(iAtom, self.atomNameArray[iAtom], \
            		self.isCAtomArray[iAtom], \
            		self.isNAtomArray[iAtom], \
            		self.isCaAtomArray[iAtom], \
            		self.isBBAtomArray[iAtom], \
            		self.isHydrogenArray[iAtom],\
            		self.hostHeavyAtomArray[iAtom]), flush = True)
            iAtom = self.atomArray[iAtom]
        
        return
    #END

    def print_molecule_info(self):
        """ Print the information of its constituent atoms in PDB style without the coordinates """

        print(' Name' , self.name, flush = True)
        print(' numatoms' , self.numAtoms, flush = True)
        print(' numRes' , self.numResidues, flush = True)
        print(' numCopies' , self.numCopies, flush = True)
        print(' numAtomsPercopy', self.numAtomsPerCopy, flush = True)

        print(' resid array', self.residArray, flush = True) 
        print(' resname array' ,self.resnameArray, flush = True)

        
        for aIdx in range(self.numAtoms):
            rIdx = self.atomResidueIdxArray[aIdx]
            print('{:<6s}{:>5d}{:>4s} {:3s} {:>4d} {:>8.4f}'.\
            	format('ATOM',self.atomIndexArray[aIdx], \
            		self.atomNameArray[aIdx], \
            		self.resnameArray[rIdx], \
            		self.residArray[rIdx], \
            		self.atomMassArray[aIdx]), flush = True)
        return
    #END

    def get_atoms_in_resid(self, arg_resid):
        """ Return the 0-indexed list of atoms in the residue with the input resid. """
        atomList = []
        iAtom = int(self.residueHead[arg_resid])
        while iAtom != -1:
            atomList.append(iAtom)
            iAtom = int(self.atomArray[iAtom])

        return atomList
    #END

    def get_atom_info(self, arg_aidx):
    	""" Print atom info in the order: SEGID RESID RESNAME ATOMNAME ATOMID """
    	segn = self.atomSegnameArray[arg_aidx]
    	resi = self.residArray[self.atomResidueIdxArray[arg_aidx]]
    	resn = self.resnameArray[self.atomResidueIdxArray[arg_aidx]]
    	aname = self.atomNameArray[arg_aidx]
    	anumb = self.atomIndexArray[arg_aidx]

    	retStr = "{:<8s}{:<8d}{:<8s}{:<8s}{:<8}".format(segn, resi, resn, aname, anumb)
    	return retStr
    #END

    def is_same_residue(self, arg_aidx1, arg_aidx2):
    	"""Return True if two atoms (0-indexed) belong to the same residue"""
    	retBool = (self.atomSegnameArray[arg_aidx1] == self.atomSegnameArray[arg_aidx2])
    	retBool = (retBool and (self.atomResidueIdxArray[arg_aidx1] == self.atomResidueIdxArray[arg_aidx2]))
    	return retBool
    #END

    def is_same_segment(self, arg_aidx1, arg_aidx2):
    	"""Return True if two atoms (0-indexed) belong to the same segment"""
    	return self.atomSegnameArray[arg_aidx1] == self.atomSegnameArray[arg_aidx2]
    #END

    def is_12(self, arg_aidx1, arg_aidx2):
    	return (self.connectivity[arg_aidx1, arg_aidx2] == 2)
    #END

    def is_13(self, arg_aidx1, arg_aidx2):
        return (self.connectivity[arg_aidx1, arg_aidx2] == 3)
    #END

    def is_14(self, arg_aidx1, arg_aidx2):
        return (self.connectivity[arg_aidx1, arg_aidx2] == 4)
    #END


    	



  



