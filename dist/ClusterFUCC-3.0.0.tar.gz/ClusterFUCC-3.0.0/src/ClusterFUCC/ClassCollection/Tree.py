"""
A class of tree nodes and binary search tree.
"""
import copy

class TreeNode(object):
	""" A generic data structure that depicts a node for a binary tree. 
	Has a pointer to one parent and 2 children """

	def __init__(self, arg_leftChildNode, arg_rightChildNode, arg_value):
		self.leftChildNode = arg_leftChildNode
		self.rightChildNode = arg_rightChildNode
		self.value = arg_value

	def __lt__(self, arg_otherNode):
		assert(self.value != None and arg_otherNode.value != None)
		return self.value < arg_otherNode.value

	def __gt__(self, arg_otherNode):
		assert(self.value != None and arg_otherNode.value != None)
		return self.value > arg_otherNode.value

	def isNA(self):
		return self.value == None and self.leftChildNode == None and self.rightChildNode == None

	def add_child(self, arg_node):
		if arg_node > self:
			self.rightChildNode = arg_node
		elif arg_node < self:
			self.leftChildNode = arg_node

		arg_node.parentNode = self
		return
	#END


#END

class BinaryTree(object):
	""" A rooted bindary tree which will be defined by a root tree node. It will be populated by links 
	to the root nodes and their subsequent links"""
	def __init__(self):
		self.rootNode = None
		self.nodeCount = 0

	def __len__(self):
		return self.nodeCount
	#END


	def add_node(self, arg_parentNode, arg_node):
		if self.rootNode is None:
			self.rootNode = arg_node
			self.incr_nodeCount()
			return

		if arg_parentNode is None:
			raise ValueError('Cannot add a child to a NONE node. Exiting...')

		if arg_node < arg_parentNode:
			if arg_parentNode.leftChildNode is None:
				arg_parentNode.leftChildNode = arg_node
				self.incr_nodeCount()
				return
			else:
				self.add_node(arg_parentNode.leftChildNode, arg_node)

		elif arg_node > arg_parentNode:
			if arg_parentNode.rightChildNode is None:
				arg_parentNode.rightChildNode = arg_node
				self.incr_nodeCount()
				return
			else:
				self.add_node(arg_parentNode.rightChildNode, arg_node)

	#END

	def delete_node(self, arg_rootNode, arg_value):
		"""
		Delete a node whose value is equal to `arg_value` from the tree
		and return the new root. VERY FUCKING TRICKY!
		"""
		if arg_rootNode is None:
			return None

		if arg_value > arg_rootNode.value:
			arg_rootNode.rightChildNode = self.delete_node(arg_rootNode.rightChildNode, arg_value)

		elif arg_value < arg_rootNode.value:
			arg_rootNode.leftChildNode = self.delete_node(arg_rootNode.leftChildNode, arg_value)

		else:
			# arg_value == arg_rootNode.value:
			# found it.
			# now depending upon how it branches out and all,
			# take the appropriate action.

			# if the node has one or no child
			if arg_rootNode.rightChildNode is None:
				tempNode = arg_rootNode.leftChildNode
				arg_rootNode = None
				self.decr_nodeCount()
				return tempNode

			if arg_rootNode.leftChildNode is None:
				tempNode = arg_rootNode.rightChildNode
				arg_rootNode = None
				self.decr_nodeCount()
				return tempNode

			# what if it has both child?
			# Ans: find min node in the subtree rooted at its
			# right child to replace it
			tempNode = self.get_min_node(arg_rootNode.rightChildNode)

			# swap its contents with that node
			arg_rootNode.value = tempNode.value

			arg_rootNode.rightChildNode = self.delete_node(arg_rootNode.rightChildNode, tempNode.value)

		return arg_rootNode

	#END

	def search_node(self, arg_node, arg_value):
		"""
		Return the node whose value equals `arg_value` or return None.
		"""
		
		retNode = None

		if arg_node is None:
			return None

		if arg_value < arg_node.value:
			retNode = self.search_node(arg_node.leftChildNode, arg_value)

		elif arg_value > arg_node.value:
			retNode = self.search_node(arg_node.rightChildNode, arg_value)

		else:
			retNode = arg_node

		return retNode
	#END
	

	def get_max_node(self, arg_node):
		"""Return the right most node in the subtree rooted at `arg_node`."""
		currNode = arg_node

		while currNode.rightChildNode != None :
			currNode = currNode.rightChildNode

		return currNode
	#END

	def get_min_node(self, arg_node):
		"""Return the left most node in the subtree rooted at `arg_node`."""
		currNode = arg_node

		while currNode.leftChildNode != None :
			currNode = currNode.leftChildNode

		return currNode
	#END

	def list_in_order(self, arg_node):
		"""
		Return a list of tree elements arranged in-order rooted at `arg_node`.
		"""

		retList = []
		self.in_order(arg_node, retList)
		return retList
	#END

	def in_order(self, arg_node, arg_outList):
		if self.rootNode is None:
			raise ValueError('Cannot traverse a tree with no root. Exiting...')

		if arg_node.leftChildNode != None:
			self.in_order(arg_node = arg_node.leftChildNode, arg_outList = arg_outList)
		arg_outList.append(arg_node) 
		if arg_node.rightChildNode != None:
			self.in_order(arg_node = arg_node.rightChildNode, arg_outList = arg_outList) 

		return		
	#END

	
	def incr_nodeCount(self):
		self.nodeCount += 1
		return

	#END

	def decr_nodeCount(self):
		self.nodeCount -= 1
		return
	#END

#END
