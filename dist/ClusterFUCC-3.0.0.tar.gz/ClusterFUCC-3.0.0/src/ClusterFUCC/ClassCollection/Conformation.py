import os, sys
from collections import Set
from ClusterFUCC.ClassCollection import Tree


class Conformation(object):
    """A class that represents the conformation of a system by the number of heavy atom contacts in it."""
    
    def __init__(self):
        self.time = None
        self.ncontacts = 0
        self.contacts = set()
        self.neighbors = set()
        self.clustered = False
        self.clusterID = -1
        self.confID = (-1, -1)
        
    def update_neighbors(self):
        newList = set()
        for nn in self.neighbors:
            if not nn.clustered:
                newList.add(nn)
                
        self.neighbors = newList
        return
    
    def get_timeStamp(self):
        return str(self.time)

    def set_confID(self, arg_id):
        self.confID = arg_id
    
    # def __eq__(self, other):
    #     return self.confID == other.confID
    
    def __gt__(self, other):
        return self.confID > other.confID
    
    def __lt__(self, other):
        return self.confID < other.confID
    
    def __hash__(self):
        return hash(self.time)
    
    #END