""" A module/collection of classes that store information 
about the bonded properties of a molecule. E.g. bonds, angles, dihedrals"""

import numpy as nmp
import sys

from CodeEntropy.FunctionCollection import GeometricFunctions as GF
from CodeEntropy.FunctionCollection import CustomFunctions as CF
from CodeEntropy.ClassCollection import CustomDataTypes as CDT

class BondedStruct(object):
    def __init__(self, arg_atomIndices, arg_baseMolecule):
        self.numAtoms = len(arg_atomIndices)
        self.atomList = arg_atomIndices
        self.baseMolecule = arg_baseMolecule

        try:
            assert(len(nmp.unique(self.atomList)) == self.numAtoms)
        except:
            raise AssertionError('Atom indices are repeated in the input list.')

    def __hash__(self):
        return hash(tuple(self.atomList))

    def __str__(self):
        return ("{} "*self.numAtoms).format(self.atomList)

    def __lt__(self, arg_other):
        return sorted(self.atomList) < sorted(arg_other.atomList)

    def __gt__(self, arg_other):
        return sorted(self.atomList) > sorted(arg_other.atomList)
#END

class Bond(BondedStruct):
    """ Bond between two atoms (preferably covalent). 
    May serve as a parent of 'contact' """

    def __init__(self, arg_atomIndices2, arg_baseMolecule):
        super().__init__(arg_atomIndices2, arg_baseMolecule)
        try:
            assert(self.numAtoms == 2)
        except:
            raise AssertionError('A bond should be initialized with 2 distinct atoms')

        self.atom1, self.atom2 = self.atomList
        return

    def is_heavy_bond(self):
        """ Based on the information in the base molecule's arrays, see if  the atoms
        in the bond are heavy atoms """
        retBool = self.baseMolecule.isHydrogenArray[self.atom1] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom2]

        return not retBool
#END

class Angle(BondedStruct):
    """ Angle composed of 3 positions. """

    def __init__(self, arg_atomIndices3, arg_baseMolecule):
        super().__init__(arg_atomIndices3, arg_baseMolecule)
        try:
            assert(self.numAtoms == 3)
        except:
            raise AssertionError('An angle should be initialized with 3 distinct atoms.')
        
        self.atom1, self.atom2, self.atom3 = self.atomList

    def is_heavy_bond(self):
        """ Based on the information in the base molecule's arrays, see if  the atoms
        in the bond are heavy atoms """
        retBool = self.baseMolecule.isHydrogenArray[self.atom1] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom2]
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom3]

        return not retBool
#END


class Dihedral(BondedStruct):
    """ Dihedral composed of 4 positions (2 planes with an intersecting line) """

    def __init__(self, arg_atomIndices4, arg_baseMolecule):
        super().__init__(arg_atomIndices4, arg_baseMolecule)
        
        try:
            assert(self.numAtoms == 4)
        except:
            raise AssertionError('A dihedral should be initialized with 4 distinct atoms')

        self.atom1, self.atom2, self.atom3, self.atom4 = self.atomList

    def __lt__(self, arg_other):
        return sorted(self.atomList[1:3]) < sorted(arg_other.atomList[1:3])

    def __gt__(self, arg_other):
        return sorted(self.atomList[1:3]) > sorted(arg_other.atomList[1:3])

    def is_heavy_dihedral(self):
        """ Based on the information in the base molecule's arrays, see if all the atoms
        in this dihedral are heavy atoms """
        retBool = self.baseMolecule.isHydrogenArray[self.atom1] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom2] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom3] 
        retBool = retBool or self.baseMolecule.isHydrogenArray[self.atom4]

        return not retBool
    #END

    def is_BB_dihedral(self):
        """ Based on the information in the base molecule's arrays, see if 2-3 atoms 
        in this dihedral are BB atoms """
        retBool = self.baseMolecule.isBBAtomArray[self.atom2] 
        retBool = retBool and self.baseMolecule.isBBAtomArray[self.atom3] 
        return retBool
    #END

    def is_BB_psi(self):
        """ Checks if a heavy dihedral is BB psi (X-C-----Ca-Y)"""
        if self.is_BB_dihedral():
            if self.baseMolecule.isCAtomArray[self.atom2] and self.baseMolecule.isCaAtomArray[self.atom3]:
                return True
            elif self.baseMolecule.isCAtomArray[self.atom3] and self.baseMolecule.isCaAtomArray[self.atom2]:
                return True
            else:
                return False
        else:
            # if not a BB dihedral, it aint a PHI or PSI
            return False
    #END

    def is_BB_phi(self):
        """ Checks if a heavy dihedral is BB phi (X-Ca-----N-Y)"""
        if self.is_BB_dihedral():
            if self.baseMolecule.isNAtomArray[self.atom2] and self.baseMolecule.isCaAtomArray[self.atom3]:
                return True
            elif self.baseMolecule.isNAtomArray[self.atom3] and self.baseMolecule.isCaAtomArray[self.atom2]:
                return True
            else:
                return False
        else:
            # if not a BB dihedral, it aint a PHI or PSI
            return False
    #END

    def is_from_same_residue(self):
        """ Based on the information in the base molecule's arrays, see if the two central atoms (2,3)
        in this dihedral belong to the same residue. Return the residue index if yes, else -100"""
        if self.baseMolecule.atomResidueIdxArray[self.atom2] ==\
        self.baseMolecule.atomResidueIdxArray[self.atom3]:
            return self.baseMolecule.atomResidueIdxArray[self.atom2]
        else:
            return -10000
    #END

    
