import numpy as nmp
from collections import Set
from ClusterFUCC.ClassCollection import Conformation, Cluster
import copy

def get_FCC(arg_conf1, arg_conf2):
    """
    Return the percent similarity of the contacts in two objects of Class Conformation.
    """
    cc12 = arg_conf1.contacts.intersection(arg_conf2.contacts)
    fcc12 = 100 * len(cc12)/arg_conf1.ncontacts
    
    return fcc12
#END


def rejig_clusters(arg_clusterList):
    """
    Checks if a member of the input cluster should belong to any other cluster
    which is possible if it is closer to that centroid than the current one. If 
    found, its clusterID is changed and cluster members are rejigged.
    """
    nRejigged = 0
    templist = []

    # for each cluster
    for iClus in arg_clusterList:
        # for each of its members
        for iMem in iClus.members:

            templist.append(iMem)

            # measure its FCC with current centroid
            currFCC = get_FCC(iMem, iClus.centroid)
            oldClusterID = copy.copy(iMem.clusterID)

            for jClus in arg_clusterList:
                otherFCC = get_FCC(iMem, jClus.centroid)

                if currFCC < otherFCC:
                    # belongs to that other cluster
                    iMem.clusterID = jClus.clusterID
                    
            if oldClusterID != iMem.clusterID:
                nRejigged += 1

    # with potentially amended clusterIDs, create new
    # member list for every cluster in the list
    for iClus in arg_clusterList:
        iClus.members = set(filter(lambda iConf: iConf.clusterID == iClus.clusterID, templist))
    return
#END


